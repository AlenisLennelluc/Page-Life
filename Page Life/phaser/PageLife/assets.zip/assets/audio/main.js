

var game = new Phaser.Game(600, 800, Phaser.AUTO, '');  //{preload: preload, create: create, update: update }


var MainMenu = function(game){

};
MainMenu.prototype = {

  preload:function() {
    // preload assets
    //game audio
    game.load.audio('pop01', 'assets/audio/pop01.mp3');
    game.load.audio('oof', 'assets/audio/oof.mp3');

    game.load.path = game.load.path + 'assets/img/';    //new loading line going to img folder.
    game.load.image('sky', 'sky.png');
    game.load.image('platform', 'platform.png');
    game.load.image('star', 'star.png');
    game.load.image('diamond', 'diamond.png');
    game.load.image('snow', 'snow.png');
    game.load.spritesheet('dude', 'dude.png', 32, 48);
    game.load.spritesheet('baddie', 'baddie.png', 32, 32);



  },
  create: function() {
    game.stage.backgroundColor = "005DFF";
    game.add.text(16, 16, 'Star Game!\nUse Arrow Keys to Move\nPress [Space] to Start', { fontSize: '32px', fill: '#FFFFFF'});

  },

  update: function() {
    if(game.input.keyboard.isDown(Phaser.Keyboard.SPACEBAR)){
      game.state.start('Play');
    }
}
}
var Play = function(game){

};
Play.prototype = {
  //initializers HOW TO DO.
  //platforms, player, cursors, stars, diamonds, baddies, baddie1, baddie2, score, scoreText,

    create:function() {
      // Initializing the Play variables

      this.platforms,
      this.player,
      this.cursors,
      this.stars,
      this.diamonds,
      this.baddies,
      this.baddie1,
      this.baddie2,
      this.pop01,
      this.oof,

      this.score= 0,
      this.scoreText,

    //Adding physics using the Arcade Physics system
    game.physics.startSystem(Phaser.Physics.ARCADE);

    // Adding a background
    game.add.sprite(0, 0, 'sky');

    //Creating a group for all ground objects
    this.platforms = game.add.group();

    //Enable physics for platforms group
    this.platforms.enableBody = true;

    //Creating the ground
    var ground = this.platforms.create(0, game.world.height - 64, 'platform');

    //Scale to fit width of game. (Orginal sprite size = 400x32px)
    ground.scale.setTo(2,2);       //this is doubling to 800x64px

    //Disable gravity on ground
    ground.body.immovable = true;

    //Create two ledges
    var ledge = this.platforms.create(400, 400, 'platform')

    ledge.body.immovable = true;

    ledge = this.platforms.create(-150, 300, 'platform')

    ledge.body.immovable = true;

    //adding two more ledges for assignment

    ledge = this.platforms.create(-250, 150, 'platform');

    ledge.body.immovable = true;

    ledge = this.platforms.create(-100, 600, 'platform');

    ledge.body.immovable = true;

    //PLAYER and PLAYER SETTINGS

    this.player = game.add.sprite(32, game.world.height - 150, 'dude');
		game.physics.arcade.enable(this.player); // Enable physics
		this.player.body.bounce.y = 0.2;	// Add a bounce effect
		this.player.body.gravity.y = 300; // Add gravity
		this.player.body.collideWorldBounds = true; // Make it so the player can't move off screen

    // ANIMATIONS walking LEFT and RIGHT
    this.player.animations.add('left', [0, 1, 2, 3], 10, true);
    this.player.animations.add('right', [5, 6, 7, 8], 10, true);

    // Look for cursor input.
    this.cursors = game.input.keyboard.createCursorKeys();

    /////////
    //STARS//
    /////////

    //Add stars to group
    this.stars = game.add.group();

    //Enable star body
    this.stars.enableBody = true;

    //Create 12 stars in for loop
    for (var i = 0; i < 12; i++)
    {
      //Create stars in for loop
      var star = this.stars.create(i * 50, 0, 'star');

      //Enable gravity on stars
      star.body.gravity.y = 120;

      //random bounce value
      star.body.bounce.y = 0.7 + Math.random() * 0.2;
    }

    ////////////
    //DIAMONDS//
    ////////////

    //add diamond to group
    this.diamonds = game.add.group();

    //add diamond in random spot

    this.diamonds.enableBody = true;

    var diamond = this.diamonds.create(Math.random()*600, Math.random()*800, 'diamond');

    //////////
    //BADDIE//
    //////////

    //make group of bad guys
    this.baddies = game.add.group();

    //add baddies to map
    this.baddies.enableBody = true;

    var baddie1 = this.baddies.create(100, 500, 'baddie');
    baddie1.body.gravity.y = 300;

    var baddie2 = this.baddies.create(470, 300 , 'baddie');
    baddie2.body.gravity.y = 300;

    //ENEMY ANIMATIONS walking LEFT and RIGHT
    baddie1.animations.add('left', [0, 1], 10, true);

    //ENEMY ANIMATIONS walking LEFT and RIGHT
    baddie2.animations.add('right', [2, 3], 10, true);

    //Play enemy animations
    baddie1.animations.play('left');
    baddie2.animations.play('right');

    ////////
    //SNOW//
    ////////

    //100 snowflakes
    for(var i = 0; i < 100; i++){
      var snow = new SnowStorm(game, 'snow');
      game.add.existing(snow);
    }

    //SCORE TEXT DISPLAY
    this.scoreText = game.add.text(16, 16, 'score: 0', { fontSize: '32px', fill: '#000' });

    /////////////////
    //END OF CREATE//
    /////////////////
    },

    update:function() {

    ///////////
    //PHYSICS//
    ///////////

    //Collide objects with this.platforms.
    var hitPlatform = game.physics.arcade.collide(this.player, this.platforms);

    // Collide player with platform.
    this.physics.arcade.collide(this.player, this.platforms);

    //check collision between this.platforms and stars
    game.physics.arcade.collide(this.stars, this.platforms);

    //Check for player overlap with stars
    game.physics.arcade.overlap(this.player, this.stars, collectStar, null, this);

    //Check for player overlap with diamond
    game.physics.arcade.overlap(this.player, this.diamonds, collectDiamond, null, this);

    //check collision between this.platforms and baddie1
    game.physics.arcade.collide(this.baddies, this.platforms);

    //Check for player overlap with baddie1
    game.physics.arcade.overlap(this.player, this.baddies, collectBaddie, null, this);

    ////////////
    //MOVEMENT//
    ////////////

    if (this.cursors.left.isDown)
    {
      // Move LEFT
      this.player.body.velocity.x = -150;
      // Play 'left' animation
      this.player.animations.play('left');
    }
      else if (this.cursors.right.isDown)
      {
        // Move RIGHT
        this.player.body.velocity.x = 150;
        // Play 'right' animtion
        this.player.animations.play('right');
      }
        else
        {
          // Stand still
          this.player.animations.stop();   // stop player animation

          // Reset player's velocity (movement)
          this.player.body.velocity.x = 0;

          this.player.frame = 4;           // go to frame 4
        }

      //JUMPING
        //Allow player to jump if on ground.
        if (this.cursors.up.isDown && this.player.body.touching.down && hitPlatform)
        {
            this.player.body.velocity.y = -350;
        }

    //game audio
    this.pop01 = game.add.audio('pop01');
    this.oof = game.add.audio('oof');

    /////////////////
    //END OF UPDATE//
    /////////////////
    }
}

  /////////////////////
  //END OF PLAY STATE//
  /////////////////////



var GameOver = function(game){

};
GameOver.prototype = {
  init:function(score){
    game.stage.backgroundColor = "005DFF"
    game.add.text(16, 16, 'Game Over\nYour score is: ' + score + '\nPress [Space] to Retry', { fontSize: '32px', fill: '#FFFFFF'});
    starCounter = 0;


  },

  update:function(){
    if(game.input.keyboard.isDown(Phaser.Keyboard.SPACEBAR)){
      game.state.start('Play');
      score = 0;
    }
  }

};

  ///////////////////
  //Global Variable//
  ///////////////////
var starCounter = 0;

//define states and load test states
game.state.add('MainMenu', MainMenu);
game.state.add('Play', Play);
game.state.add('GameOver', GameOver);
game.state.start('MainMenu');


    /////////////////////
    //COLLECT FUNCTIONS//
    /////////////////////

    function collectStar (player, star){
      //removes star from screen
      star.kill();

      //Play Sound
      this.pop01.play('', 0, 1, false);

      this.score += 10;
      this.scoreText.text = 'Score: ' + this.score;

      starCounter++;

      // If all stars collected, go to game over
      if(starCounter == 12){
      game.state.start('GameOver', true, false, this.score);
      }
    }

    function collectDiamond (player, diamond){
      //removes diamond from screen
      diamond.kill();

      //Play Sound
      this.pop01.play('', 0, 1, false);

      this.score += 50;
      this.scoreText.text = 'Score: ' + this.score;

    }

    function collectBaddie (player, baddie){
      //removes baddie1 from screen
      baddie.kill();

      //Play oof
      this.oof.play('', 0, 1, false);

      this.score -= 25;
      this.scoreText.text = 'Score: ' + this.score;

      //load "GameOver" state
      game.state.start('GameOver', true, false, this.score);
    }

    ////////////////////////////
    //END OF COLLECT FUNCTIONS//
    ////////////////////////////

    //////////////////
    //END OF MAIN.JS//
    //////////////////
